# ASC2017
Acoustic Scene Classification 2017 Comparison study



# Structure of the package
ASC2017/ <br/>
│ <br/>
├── Code/ <br/>
      ├── dataProcessing/ <br/>
      ├── feature_extraction/ <br/>
      ├── model/ <br/>
      ├── sys_folder/ <br/>
├── .gitignore <br/>
├── README.md <br/>
