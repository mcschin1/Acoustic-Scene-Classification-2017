# -*- coding: utf-8 -*-
"""
Created on Wed Jan 29 21:45:01 2020

@author: sonat
"""
from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input)
from model import cnnBB

__all__=['CBAM']

def CBAM(dataConfig,learning_rate=0.001):
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((256,256,1)))
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,strides=(2,2))
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.res_block(x,64,attention=True,shortcut_con=False)
    x = cnnBB.res_block(x,128,attention=True,strides=2)
    x = cnnBB.res_block(x,128,attention=True,shortcut_con=False)
    x = cnnBB.res_block(x,256,attention=True,strides=2)
    x = cnnBB.res_block(x,256,attention=True,shortcut_con=False)
    x = cnnBB.res_block(x,512,attention=True,strides=2)
    x = cnnBB.res_block(x,512,attention=True,shortcut_con=False)
    x = cnnBB.res_block(x,1024,attention=True,strides=2)
    x = cnnBB.res_block(x,1024,attention=True,shortcut_con=False)
    x = cnnBB.res_block(x,1024,attention=True,shortcut_con=False)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model