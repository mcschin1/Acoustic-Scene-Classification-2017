# -*- coding: utf-8 -*-
"""
Created on Thu Jan  9 18:19:59 2020

@author: kekxi
"""


from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input)
from model import cnnBB

__all__=['WRN']

def WRN(dataConfig,learning_rate=1e-2):
    '''
    Wide residual network using bottleneck approach instead of the standard approach
    
    
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    x = cnnBB.keras_conv_2d(input_shape,32,7,7,strides=2)
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.res_block_w(x, 64,stride=2)
    x = cnnBB.res_block_w(x, 64)
    x = cnnBB.res_block_w(x, 128,stride=2)
    x = cnnBB.res_block_w(x, 128)
    x = cnnBB.res_block_w(x, 256,stride=2)
    x = cnnBB.res_block_w(x, 256)
    x = cnnBB.res_block_w(x, 512,stride=2)
    x = cnnBB.res_block_w(x, 512)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model