# -*- coding: utf-8 -*-
"""
Created on Tue Dec 24 13:20:33 2019

@author: sonat
"""
from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input,
                          ZeroPadding2D,MaxPooling2D)
from model import cnnBB

__all__=['resNET','resNET2','resNET3','resNET_V2','resnXet','resNet2017']

def resNET(dataConfig,learning_rate=0.001,input_tensor=None):
    '''
    
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    #Layer 1
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,padding='valid',strides=(2,2),applyBatchNom=False)
    x = ZeroPadding2D(padding=((1, 1), (1, 1)), name='pool1_pad')(x)
    x = MaxPooling2D(3, strides=2, name='pool1_pool')(x)
    x = cnnBB.res_block1(x,64,strides=(2,2))
    x = cnnBB.res_block1(x,64,conv_shortcut=False)
    x = cnnBB.res_block1(x,128,strides=(2,2))
    x = cnnBB.res_block1(x,128,conv_shortcut=False)
    x = cnnBB.res_block1(x,256,strides=(2,2))
    x = cnnBB.res_block1(x,256,conv_shortcut=False)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model

def resNET2(dataConfig,learning_rate=0.001,input_tensor=None):
    '''
    For 2019 development dataset
    with input features of 256 by 470 by 1
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    #Layer 1
    x = cnnBB.keras_conv_2d(input_shape,64,5,5,padding='valid',strides=(1,1),act='relu')
    #x = ZeroPadding2D(padding=((1, 1), (1, 1)), name='pool1_pad')(x)
    x = MaxPooling2D(5, name='pool1_pool')(x)
    x = cnnBB.res_block1(x,64,strides=(5,5))
    x = cnnBB.res_block1(x,64,conv_shortcut=False)
    x = cnnBB.res_block1(x,128,strides=(2,2))
    x = cnnBB.res_block1(x,128,conv_shortcut=False)
    x = cnnBB.res_block1(x,256,strides=(2,2))
    x = cnnBB.res_block1(x,256,conv_shortcut=False)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model

def resNET3(dataConfig,learning_rate=0.001,input_tensor=None):
    '''
    For 2019 development dataset
    with input features of 256 by 470 by 1
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    #Layer 1
    x = cnnBB.keras_conv_2d(input_shape,32,5,5,padding='valid',strides=(1,1),act='relu')
    #x = ZeroPadding2D(padding=((1, 1), (1, 1)), name='pool1_pad')(x)
    x = MaxPooling2D((5,5), name='pool1_pool')(x)
    x = cnnBB.res_block(x,64,strides=(2,2))
    x = cnnBB.res_block(x,128,strides=(2,2))
    x = cnnBB.res_block(x,128,shortcut_con=False)
    x = cnnBB.res_block(x,128,shortcut_con=False)
    x = cnnBB.res_block(x,256,strides=(2,2))
    x = cnnBB.res_block(x,256,shortcut_con=False)
    x = cnnBB.res_block(x,256,shortcut_con=False)
    x = cnnBB.res_block(x,256,shortcut_con=False)
    x = cnnBB.res_block(x,256,shortcut_con=False)
    x = cnnBB.res_block(x,512,strides=(2,2),shortcut_con=True)
    x = cnnBB.res_block(x,512,shortcut_con=False)
    x = cnnBB.res_block(x,512,shortcut_con=False)
    x = cnnBB.res_block(x,512,shortcut_con=False)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model

def resNET_V2(dataConfig,learning_rate=0.001,input_tensor=None):
    '''
    No stem
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    #Layer 1
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,padding='valid',strides=(2,2),applyBatchNom=False)
    x = ZeroPadding2D(padding=((1, 1), (1, 1)), name='pool1_pad')(x)
    x = MaxPooling2D(3, strides=2, name='pool1_pool')(x)
    x = cnnBB.res_block2(x,64)
    x = cnnBB.res_block2(x,64,stride=2,conv_shortcut=False)
    x = cnnBB.res_block2(x,128)
    x = cnnBB.res_block2(x,128,stride=2,conv_shortcut=False)
    x = cnnBB.res_block2(x,256)
    x = cnnBB.res_block2(x,256,stride=2,conv_shortcut=False)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model

def resnXet(dataConfig,learning_rate=0.001,input_tensor=None):
    '''
    No stem
    '''    
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,padding='valid',strides=(2,2),act='relu')
    x = ZeroPadding2D(padding=((1, 1), (1, 1)), name='pool1_pad')(x)
    x = MaxPooling2D(3, strides=2, name='pool1_pool')(x)
    x = cnnBB.resX_block(x,128)
    x = cnnBB.resX_block(x,128,conv_shortcut=False)
    x = cnnBB.resX_block(x,256,stride=2)
    x = cnnBB.resX_block(x,256,conv_shortcut=False)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model
    
    
    return model

def resNet2017(dataConfig,learning_rate=0.001):
    '''
    Adapted from: http://www.cs.tut.fi/sgn/arg/dcase2017/documents/challenge_technical_reports/DCASE2017_Zhao_161.pdf
    DCASE 2017 challenge
    
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    x = cnnBB.keras_conv_2d(input_shape,16,3,3,act='relu')
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.res_block(x,16,shortcut_con=False)
    x = cnnBB.res_block(x,16,shortcut_con=False)
    x = cnnBB.res_block(x,16,shortcut_con=False)
    x = cnnBB.res_block(x,32,strides=(2,2),shortcut_con=True)
    x = cnnBB.res_block(x,32,shortcut_con=False)
    x = cnnBB.res_block(x,32,shortcut_con=False)
    x = cnnBB.res_block(x,32,shortcut_con=False)
    x = cnnBB.res_block(x,64,strides=(2,2),shortcut_con=True)
    x = cnnBB.res_block(x,64,shortcut_con=False)
    x = cnnBB.res_block(x,64,shortcut_con=False)
    x = cnnBB.res_block(x,64,shortcut_con=False)
    x = cnnBB.res_block(x,64,shortcut_con=False)
    x = cnnBB.res_block(x,64,shortcut_con=False)
    x = cnnBB.res_block(x,128,strides=(2,2),shortcut_con=True)
    x = cnnBB.res_block(x,128,shortcut_con=False)
    x = cnnBB.res_block(x,128,shortcut_con=False)
    final = GlobalAveragePooling2D()(x)
    final = Dense(128)(final)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model