# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 14:50:53 2019

@author: sonat
"""
from keras.activations import relu, softmax,sigmoid
from keras import losses, models, optimizers
from keras.layers import (Convolution1D,Convolution2D, GlobalAveragePooling2D, BatchNormalization, Flatten,Conv2D,Reshape,MaxPooling2D,Dot,
                          GlobalMaxPool2D, MaxPool2D, concatenate, Activation,Dense,Dropout,Input,ZeroPadding2D, AveragePooling2D,
                          Lambda,SpatialDropout2D,Add,DepthwiseConv2D,ZeroPadding1D,MaxPooling1D,SeparableConv2D, Multiply,
                          GlobalAvgPool2D,ReLU,Reshape,Activation)
from keras.utils import Sequence, to_categorical
from keras import backend as K
from keras.initializers import glorot_normal,glorot_uniform,he_normal
from keras.backend import (sign,sqrt,l2_normalize,abs)
from keras.regularizers import l2
import tensorflow as tf
import numpy as np

        
def keras_conv_2d(x,
              filters,
              num_row,
              num_col,
              padding='same',
              strides=(1, 1),
              kernel_init='he_normal',
              name=None,
              act=None,
              applyBatchNom=True,
              alpha=1):
    '''
    Utility function to apply conv + BN. cited from Keras Team
    # Arguments
    x: input tensor.
    filters: no of filters in `Conv2D`
    num_row: height of the convolution kernel.
    num_col: width of the convolution kernel.
    padding: padding mode in `Conv2D`.
    strides: strides in `Conv2D`.
    name: name of the ops; will become `name + '_conv'`
    for the convolution and `name + '_bn'` for the
    batch norm layer.
    # Returns
    Output tensor after applying `Conv2D` and `BatchNormalization`.
    '''
        
    if name is not None:
        bn_name = name + '_bn'
        conv_name = name + '_conv'
    else:
        bn_name = None
        conv_name = None

    x = Convolution2D(
            int(filters*alpha), (num_row, num_col),
            strides=strides,
            padding=padding,
            use_bias=False,
            name=conv_name,
            kernel_regularizer=l2(0.0005),
            kernel_initializer=kernel_init)(x)
    # defaulted axis to be channel as last array
    if applyBatchNom:
        x = BatchNormalization(axis=-1, name=bn_name)(x)
    if act is not None:
        x = Activation(act, name=name)(x)
    return x

def keras_conv_1d(x,
              filters,
              kernel_size,
              padding='same',
              stride=1,
              kernel_init='he_normal',
              name=None,
              act=None,
              applyBatchNom=True):
    '''
    Utility function to apply conv1d + BN + activation function. 
    cited from Keras Team
        [github source] :- ()
    
    # Arguments
    x: input tensor.
    filters: no of filters in `Conv1D`
    num_row: height of the convolution kernel.
    num_col: width of the convolution kernel.
    padding: padding mode in `Conv1D`.
    strides: strides in `Conv1D`.
    name: name of the ops; will become `name + '_conv'`
    for the convolution and `name + '_bn'` for the
    batch norm layer.
    # Returns
    Output tensor after applying `Conv2D` and `BatchNormalization`.
    '''
        
    if name is not None:
        bn_name = name + '_bn'
        conv_name = name + '_conv'
    else:
        bn_name = None
        conv_name = None

    x = Convolution1D(
            filters, kernel_size,
            strides=stride,
            padding=padding,
            use_bias=False,
            name=conv_name,
            kernel_regularizer=l2(0.0005),
            kernel_initializer=kernel_init)(x)
    # defaulted axis to be channel as last array
    if applyBatchNom:
        x = BatchNormalization(axis=-1, name=bn_name)(x)
    if act is not None:
        x = Activation(act, name=name)(x)
    return x

def keras_separable_conv_2d(x,
              filters,
              kernel_size,
              padding='same',
              stride=1,
              depth_multi=1,
              kernel_init='he_normal',
              name=None,
              act=None,
              applyBatchNom=True):
    '''
    Utility function to apply separable conv2d + BN + activation function.
    kernel_initiatlization is default to Xaiver normalization.
    cited from Keras Team
        [github source] :- ()
    
    # Arguments
    x: input tensor.
    filters: no of filters in `separableConv2D`
    num_row: height of the convolution kernel.
    num_col: width of the convolution kernel.
    padding: padding mode in `separableConv2D`.
    strides: strides in `separableConv1D`.
    name: name of the ops; will become `name + '_conv'`
    for the convolution and `name + '_bn'` for the
    batch norm layer.
    # Returns
    Output tensor after applying `Conv2D` and `BatchNormalization`.
    '''
        
    if name is not None:
        bn_name = name + '_bn'
        conv_name = name + '_conv'
    else:
        bn_name = None
        conv_name = None

    x = SeparableConv2D(
            filters, kernel_size,
            strides=stride,
            padding=padding,
            use_bias=False,
            depth_multiplier=depth_multi,
            name=conv_name,
            depthwise_regularizer=l2(0.0005), 
            pointwise_regularizer=l2(0.0005),
            depthwise_initializer=kernel_init, 
            pointwise_initializer=kernel_init)(x)
    # defaulted axis to be channel as last array
    if applyBatchNom:
        x = BatchNormalization(axis=-1, name=bn_name)(x)
    if act is not None:
        x = Activation(act, name=name)(x)
    return x


def vgg_block(input,filters,pool_size=None):
    x = keras_conv_2d(input,filters,3,3,act='relu')
    x = keras_conv_2d(x,filters,3,3,act='relu')
    if pool_size is not None:
        x = MaxPooling2D(pool_size=pool_size)(x)
    else:
        x = MaxPooling2D(pool_size=(2,2),strides=(2,2))(x)
    return x

def incep_block1(input,filters,curr_filter=None,ins_channel=False,padding='same'):
    if ins_channel and curr_filter is None:
        curr_filter=filters-64
    
    branch1 = keras_conv_2d(input,filters,1,1,act='relu')
    if not ins_channel:   
        branch2 = keras_conv_2d(input,filters,1,1,act='relu')
        branch2 = keras_conv_2d(branch2,filters,3,3,act='relu')
    else:
        branch2 = keras_conv_2d(input,curr_filter,1,1,act='relu')
        branch2 = keras_conv_2d(branch2,filters,3,3,act='relu')
    if not ins_channel:
        branch3 = keras_conv_2d(input,filters,1,1,act='relu')
        branch3 = keras_conv_2d(branch3,filters,3,3,act='relu')
        branch3 = keras_conv_2d(branch3,filters,3,3,act='relu')
    else:
        branch3 = keras_conv_2d(input,curr_filter,1,1,act='relu')
        branch3 = keras_conv_2d(branch3,curr_filter,3,3,act='relu')
        branch3 = keras_conv_2d(branch3,filters,3,3,act='relu')
    if not ins_channel:
        branch4 = AveragePooling2D(pool_size=(3,3),strides=(1,1))
        branch4 = keras_conv_2d(input,filters,1,1,act='relu')
    else:
        branch4 = AveragePooling2D(pool_size=(3,3),strides=(1,1))
        branch4 = keras_conv_2d(input,curr_filter,1,1,act='relu') 
    
    out = concatenate(
            [branch1,branch2,branch3,branch4],axis=3
            )
    return out

def incep_block2(input,filters,curr_filter=None,ins_channel=False):
    '''
    Incep block2 simulate filters factorization. 7 x 1, 1 x 7
    '''
    if ins_channel and curr_filter is None:
        curr_filter=filters-64
    
    branch1 = keras_conv_2d(input,filters,1,1,act='relu')
    if not ins_channel:
        branch2 = keras_conv_2d(input,filters,1,1,act='relu')
        branch2 = keras_conv_2d(branch2,filters,1,7,act='relu')
        branch2 = keras_conv_2d(branch2,filters,7,1,act='relu')
    else:
        branch2 = keras_conv_2d(input,curr_filter,1,1,act='relu')
        branch2 = keras_conv_2d(branch2,curr_filter,1,7,act='relu')
        branch2 = keras_conv_2d(branch2,filters,7,1,act='relu')
    if not ins_channel:
        branch3 = keras_conv_2d(input,filters,1,1,act='relu')
        branch3 = keras_conv_2d(branch3,filters,7,1,act='relu')
        branch3 = keras_conv_2d(branch3,filters,1,7,act='relu')
        branch3 = keras_conv_2d(branch3,filters,7,1,act='relu')
        branch3 = keras_conv_2d(branch3,filters,1,7,act='relu')
    else:
        branch3 = keras_conv_2d(input,curr_filter,1,1,act='relu')
        branch3 = keras_conv_2d(branch3,curr_filter,7,1,act='relu')
        branch3 = keras_conv_2d(branch3,curr_filter,1,7,act='relu')
        branch3 = keras_conv_2d(branch3,curr_filter,7,1,act='relu')
        branch3 = keras_conv_2d(branch3,filters,1,7,act='relu')
    
    branch4 = AveragePooling2D(pool_size=(3,3),strides=(1,1),padding='same')
    branch4 = keras_conv_2d(input,filters,1,1,act='relu')
    out = concatenate(
            [branch1,branch2,branch3,branch4],axis=3
            )
    return out

def incep_dim_reduce3x3(input,filters,kernel_h=3,kernel_w=3,fstrides=(2,2),act='relu'):
    half_channel=input.shape[3]//2
    branch1 = keras_conv_2d(input,half_channel,kernel_h,kernel_w,strides=fstrides,padding='valid',act=act)
    
    branch2 = keras_conv_2d(input,filters-32,1,1,act=act)
    branch2 = keras_conv_2d(branch2,filters,3,3,act=act)
    branch2 = keras_conv_2d(branch2,filters,kernel_h,kernel_w,strides=fstrides,padding='valid',act=act)
    
    branch3 = MaxPooling2D(pool_size=(kernel_h,kernel_w),strides=fstrides)(input)
    out = concatenate(
            [branch1,branch2,branch3]
            )
    return out

def incep_dim_reduce7x7(input,filters,kernel_h=3,kernel_w=3,fstrides=(2,2),act='relu'):
    half_channel=input.shape[3]//2
    branch1 = keras_conv_2d(input,half_channel,kernel_h,kernel_w,strides=fstrides,padding='valid',act=act)
    
    branch2 = keras_conv_2d(input,filters-32,1,1,act=act)
    branch2 = keras_conv_2d(branch2,filters,7,1,act=act)
    branch2 = keras_conv_2d(branch2,filters,1,7,act=act)
    branch2 = keras_conv_2d(branch2,filters,kernel_h,kernel_w,strides=fstrides,padding='valid',act=act)
    
    branch3 = MaxPooling2D(pool_size=(kernel_h,kernel_w),strides=fstrides)(input)
    out = concatenate(
            [branch1,branch2,branch3]
            )
    return out


def res_block(input,filters,kernel_size=3,strides=(1,1),act='relu',shortcut_con=True,attention=False):
    '''
    Resnet first version of the building block
    A Res_BLOCK consist of 3-4 weighted layers
    GitHub: [https://github.com/keras-team/keras-applications/blob/master/keras_applications/resnet_common.py]
    Mainly used for network that is less than 50-layers
    '''
    if shortcut_con:
        shortcut = keras_conv_2d(input,filters,1,1,padding='valid',strides=strides)
    else:
        shortcut = input
    x = ZeroPadding2D(padding=((1,1),(1,1)))(input)
    x = keras_conv_2d(x,filters,kernel_size,kernel_size,act=act,padding='valid',strides=strides)
    x = keras_conv_2d(x,filters,kernel_size,kernel_size)
    if attention:
        out = channel_attention(x)
        out = Add()([shortcut,out])
    else:
        out = Add()([shortcut,x])
    out = Activation('relu')(out)
    return out


def res_block1(input,filters,kernel_size=3,strides=(1,1),act='relu',conv_shortcut=True):
    '''
    Resnet first version of the building block for more than 50 layers
    A Res_BLOCK consist of 3-4 weighted layers
    GitHub: [https://github.com/keras-team/keras-applications/blob/master/keras_applications/resnet_common.py]
    
    '''
    if conv_shortcut:
        shortcut = keras_conv_2d(input,4*filters,1,1,padding='valid',strides=strides)
    else:
        shortcut = input
    x = keras_conv_2d(input,filters,1,1,act=act,padding='valid',strides=strides)
    x = keras_conv_2d(x,filters,kernel_size,kernel_size,act=act)
    x = keras_conv_2d(x,4*filters,1,1)
    out = Add()([shortcut,x])
    out = Activation('relu')(out)
    return out
    
def stack_resblock1(x,filters):
    x = res_block1(x, filters, strides=(2,2))
    x = res_block1(x, filters, conv_shortcut=False)
    x = res_block1(x,filters,conv_shortcut=False)
    return x

def res_block2(input,filters,kernel_size=3,stride=1,act='relu',conv_shortcut=True):
    '''
    Resnet upgrade version of the building block
    A Res_BLOCK consist of 3-4 weighted layers
    '''
    preact = BatchNormalization(axis=-1)(input)
    preact = Activation('relu')(preact)
    
    if conv_shortcut:
        shortcut= keras_conv_2d(preact,4*filters,1,1,padding='valid',strides=stride,applyBatchNom=False)    
    else:
        shortcut= MaxPooling2D(1, strides=stride)(input) if stride > 1 else input

    x = keras_conv_2d(preact,filters,1,1,padding='valid',act=act)
    x = ZeroPadding2D(padding=((1,1),(1,1)))(x)
    x = keras_conv_2d(x,filters,kernel_size,kernel_size,strides=(stride,stride),act=act,padding='valid')
    x = keras_conv_2d(x,4*filters,1,1,applyBatchNom=False,padding='valid')
    out = Add()([shortcut,x])
    return out

def stack_resblock2(x,filters):
    x = res_block1(x, filters,conv_shortcut=True)
    x = res_block1(x, filters, conv_shortcut=False)
    x = res_block1(x,filters,conv_shortcut=False)
    x = res_block1(x,filters,stride=2,conv_shortcut=False)
    return x


def res_block2_1d(input,filters,kernel_size=3,stride=1,act='relu',conv_shortcut=True):
    
    preact = BatchNormalization(axis=-1)(input)
    preact = Activation('relu')(preact)
    if conv_shortcut:
        shortcut= keras_conv_1d(preact,4*filters,1,padding='valid',stride=stride,applyBatchNom=False)    
    else:
        shortcut= MaxPooling1D(1, strides=stride)(input) if stride > 1 else input

    x = keras_conv_1d(preact,filters,1,act=act)
    x = ZeroPadding1D(padding=1)(x)
    x = keras_conv_1d(x,filters,kernel_size,stride=stride,act=act,padding='valid')
    x = keras_conv_1d(x,4*filters,1,applyBatchNom=False,padding='valid')
    out = Add()([shortcut,x])
    return out

def res_block_1d(input,filters,kernel_size=3,stride=1,act='relu',conv_shortcut=True,padding=1):
    
    if conv_shortcut:
        shortcut= keras_conv_1d(input,filters,1,padding='valid',stride=stride)    
    else:
        shortcut= input
        
    x = ZeroPadding1D(padding=padding)(input)
    x = keras_conv_1d(x,filters,kernel_size,stride=stride,act=act,padding='valid')
    x = keras_conv_1d(x,filters,kernel_size)
    out = Add()([shortcut,x])
    out = Activation(act)(out)
    return out

def resX_block(input,filters,kernel_size=3,stride=1,act='relu',conv_shortcut=True,groups=32):
    '''
    ResneXt block
    Introduce grouping to gracefully control the number of channels as the model go deeper.
    '''
    if conv_shortcut is True:
        shortcut = keras_conv_2d(input,(64//groups) * filters,1,1,strides=stride,padding='valid')
    else:
        shortcut = input
    x = keras_conv_2d(input,filters,1,1,act='relu')
    c = filters//groups
    x = ZeroPadding2D(padding=((1,1),(1,1)))(x)
    x = DepthwiseConv2D(kernel_size,strides=stride,depth_multiplier=c)(x)
    
    kernel = np.zeros((1, 1, filters * c, filters), dtype=np.float32)
    for i in range(filters):
        start = (i // c) * c * c + i % c
        end = start + c * c
        kernel[:, :, start:end:c, i] = 1
    kernal_init = {'class_name':'constant','config':{'value':kernel}}
    x = keras_conv_2d(x,filters,1,1,padding='valid',kernel_init=kernal_init,act=act
                      )
    x = keras_conv_2d(x,(64//groups)*filters,1,1)
    x = Add()([shortcut,x])
    x = Activation(act)(x)
    return x

def stack_resX_block(x,filters,stride=2,groups=32):
    x = resX_block(x,filters,stride=stride,groups=32)
    x = resX_block(x,filters,groups=32,conv_shortcut=False)
    x = resX_block(x,filters,groups=32,conv_shortcut=False)
    return x



def res_block_w(input,filters,width_factor=8,kernel_size=3,stride=1,act='relu'):
    '''
    Wide resnet as it is stated experiment in the focus on increasing the number of channel
    instead of just focusing on the depth of the network.
    
    GitHub : [https://github.com/osmr/imgclsmob/blob/master/tensorflow2/tf2cv/models/wrn.py]
    
    resblock with standard residual block of (1,3,1)
    widening effect of k=8
    (3 x 3, 16 x k) where 3 x 3 = kernel size and 16 x k is the number of filters
    
    
    
    '''
    in_channels = K.int_shape(input)[3]
    out_channels = filters
    mid_channels = int(round(out_channels // 4 * width_factor))
    
    if in_channels != out_channels or stride != 1:
        shortcut = keras_conv_2d(input,out_channels,1,1,strides=stride,act='relu',padding='valid')
    else:
        shortcut = input
    x = keras_conv_2d(input,mid_channels,1,1,act=act)
    x = ZeroPadding2D(padding=1)(x)
    x = keras_conv_2d(x,mid_channels,kernel_size,kernel_size,padding='valid',strides=stride,act=act)
    x = keras_conv_2d(x,out_channels,1,1)
    x = Add()([shortcut,x])
    x = Activation(act)(x)
    return x

def stack_Wresnet(x,filters,stride=2):
    x = res_block_w(x,filters,stride=stride)
    x = res_block_w(x,filters,conv_shortcut=False)
    x = res_block_w(x,filters,conv_shortcut=False)
    return x

def Xception_block(input,filters,kernel_size=3,stride=2,act='relu'):
    '''
    # Reference
    - [Xception: Deep Learning with Depthwise Separable Convolutions](
        https://arxiv.org/abs/1610.02357) (CVPR 2017)
    Xception is the combination of Residual Network with Depthwise Separable Conv
    In keras implementation, instead of conv2d, depthwise separable conv is being used.
    '''
    residual = keras_conv_2d(input,filters,1,1,strides=stride)
    x = Activation(act)(input)
    x = keras_separable_conv_2d(x,filters,kernel_size,act=act)
    x = keras_separable_conv_2d(x,filters,kernel_size)
    x = MaxPooling2D((3,3),strides=stride,padding='same')(x)
    x = Add()([x,residual])
    
    return x
    
def mobilenet_depthwise_sep_block(input,pointwise_conv_filters,kernel_size=3,alpha=1,depth_multiplier=1,
                                  stride=1,act='relu'):
    '''
    #Description
    Adaptation from mobilenet
    
    This is the implementation of mobilenet depthwise separation block.
    Adapted from keras Team implementation
    GitHub: [https://github.com/keras-team/keras-applications/blob/master/keras_applications/mobilenet.py]
    
    Each block is 2 layer deep
    
    #Arguments:
        input: 4D tensor(batch,kernel_size_height,kernel_size_width,channel)
        
            
        filters:
            
            
        alpha: controls the width of the network.
            - If `alpha` < 1.0, proportionally decreases the number
                of filters in each layer.
            - If `alpha` > 1.0, proportionally increases the number
                of filters in each layer.
            - If `alpha` = 1, default number of filters from the paper
                 are used at each layer.
    #Output:
    
    '''
    pointwise_conv_filters = int(pointwise_conv_filters * alpha)
    if stride == 1:
        x = input
    else:
        x = ZeroPadding2D(((0, 1), (0, 1)))(input)
    x = DepthwiseConv2D((3,3),padding='same' if stride == 1 else 'valid',
                        depth_multiplier=depth_multiplier,use_bias=False,strides=stride)(x)
    x = BatchNormalization(axis=-1)(x)
    x = ReLU(6.)(x)
    x = keras_conv_2d(x,pointwise_conv_filters,1,1)
    x = ReLU(6.)(x)
    return x

def mobilenetV2_depthwise_sep_block(input,filters,kernel_size,expansion=1,alpha=1,depth_multiplier=1,
                                    stride=1,act='relu',shortcut_conv=True):
    '''
    MobilenetV2 added residue framework
    This is the implementation of mobilenetV2 depthwise separation block.
    Adapted from keras Team implementation
    GitHub: [https://github.com/keras-team/keras-applications/blob/master/keras_applications/mobilenet_v2.py]
    
    
    '''
    in_channels=K.int_shape(input)[3]
    pointwise_conv_filters = int(filters * alpha)
    #Expand
    x = keras_conv_2d(input,expansion*filters,1,1)
    x = ReLU(6.)(x)
    
    #Depthwise
    if stride == 2:
        x = ZeroPadding2D(((0, 1), (0, 1)))(x)
    x = DepthwiseConv2D((3,3),padding='same' if stride == 1 else 'valid',
                        depth_multiplier=depth_multiplier,use_bias=False,strides=stride)(x)
    x = BatchNormalization(axis=-1)(x)
    x = ReLU(6.)(x)
    x = keras_conv_2d(x,pointwise_conv_filters,1,1)
    if in_channels == pointwise_conv_filters and stride == 1:
        return Add()([input, x])
    return  x

def dense_block(input,blocks,act='relu'):
    '''
    Stacking up the dense block which is increasing the number of channel and more channelwise non-linerity
    Adapted from keras Team implementation
    GitHub:[https://github.com/keras-team/keras-applications/blob/master/keras_applications/densenet.py]
    
    Consists of 2 weighted layers.
    
    # Arguments
    input : input tensor with channel as last.
    
    blocks : the number of convolution stacks on top of each dense block
    
    act : Activation function name
          Default value is set to ReLU.
    
    # Returns 
        Output tensor for the dense block
    
    '''
    growth_rate=32
    x = input
    for i in range(blocks):
        x1 = BatchNormalization()(x)
        x1 = Activation(act)(x)
        x1 = keras_conv_2d(x,4*growth_rate,1,1,act=act)
        x1 = keras_conv_2d(x,growth_rate,3,3,applyBatchNom=False)
        x = concatenate([x,x1])
    return x

def transition_block(x, reduction=0.5,act='relu'):
    '''
    Transition block mainly used for dimensionality reduction.
    
    Adapted from keras Team implementation
    GitHub:[https://github.com/keras-team/keras-applications/blob/master/keras_applications/densenet.py]
    
    #Arguments
    '''
    x = BatchNormalization()(x)
    x = Activation(act)(x)
    x = keras_conv_2d(x,int(K.int_shape(x)[3]*reduction),1,1,applyBatchNom=False)
    x = AveragePooling2D(2,strides=2)(x)
    return x

def highway_block(input,filters,H_kernel_size=3,W_kernel_size=3,act='relu', conv=False):
    '''
    Highway block is derived from highway Network 2015
    
    However, unlike the actual highway network, bias is omitted from the model.
    
    Adapted from 
    GitHub: [https://gist.github.com/iskandr/a874e4cf358697037d14a17020304535#file-keras2-highway-network-py]
            [https://github.com/trangptm/HighwayNetwork/blob/b5e28b96a8ccb27e54faf58d24c74a750f08714e/ConvHighway.py#L8]
    '''
    if conv:
        x = keras_conv_2d(input,filters,1,1)
    else:
        filters = K.int_shape(input)[-1]
        x = input
    #Compute the candidate hidden state
    transform = keras_conv_2d(x,filters,H_kernel_size,W_kernel_size,act=act)
    
    #gate
    transform_gate = keras_conv_2d(x,filters,H_kernel_size,W_kernel_size,act=sigmoid)
    carry_gate = Lambda(
            lambda x: 1.0 - x,
            output_shape=(filters,))(transform_gate)
    transform_gate = Multiply()([transform, transform_gate])
    identity_gated = Multiply()([x, carry_gate])
    out = Add()([transform_gate,identity_gated])
    return  out
    


def SENet_block(input,filters,act='relu',ratio=16):
    '''
    Squeeze & Excitation network block
    GitHub: [https://github.com/taki0112/SENet-Tensorflow/blob/master/SE_ResNeXt.py]
            [https://github.com/tensorpack/tensorpack/tree/master/examples/ResNet]
    
    #Arguments
    input :  
    
    ratio : This is the reduction ratio of the squeeze block which determine the number of nodes 
            for the first Dense layer which can be calculated by filters//ratio
            It is default to 16 according to the paper.
    
    '''
    x = input
    squeeze = GlobalAvgPool2D()(x)
    excitation = Dense(filters//ratio,activation='relu',
                            use_bias=False,kernel_regularizer=l2(0.0005))(squeeze)
    excitation = Dense(filters,activation='sigmoid',
                           use_bias=False,kernel_regularizer=l2(0.0005))(excitation)
    excitation = Reshape([1,1,filters])(excitation)
    scale = Multiply()([x,excitation])
    return scale

def resSENet_block(input,filters,kernel_size=3,stride=1,act='relu',ratio=16,conv_shortcut=False):
    '''
    #Adaptation
    Following Squeeze & Excitation network block standard residual SENET
    
    #Arguments
    
    input : tensor input
    
    filters : the number of filters.
              Due to bottleneck nature, final output for the number of channel is filters*4.
    
    stride :
    
    ratio :
    
    conv_shortcut : Whether it is shorcut connection or identity mapping as described in Resnet.
        
        
    '''
    if conv_shortcut:
        stride = 2
        shortcut = keras_conv_2d(input,filters*4,1,1,strides=stride)
    else:
        shortcut = input
    
    x = keras_conv_2d(input,filters,1,1,act=act)
    x = keras_conv_2d(x,filters,kernel_size,kernel_size,strides=stride,act=act)
    x = keras_conv_2d(x,filters*4,1,1)
    se = SENet_block(x,filters*4)
    
    x = Add()([se,shortcut])
    x = Activation(act)(x)
    
    return x

'''
def connectionist_Temporal_CNN or Atro convolution
'''


def correct_pad(inputs, kernel_size):
    '''
    Exact copy from Keras with modification to inputs:
        https://github.com/keras-team/keras-applications/blob/master/keras_applications/__init__.py
    
    Returns a tuple for zero-padding for 2D convolution with downsampling.
    # Arguments
        input_size: An integer or tuple/list of 2 integers.
        kernel_size: An integer or tuple/list of 2 integers.
    # Returns
        A tuple.
    '''
    img_dim = 1
    input_size = K.int_shape(inputs)[img_dim:(img_dim + 2)]

    if isinstance(kernel_size, int):
        kernel_size = (kernel_size, kernel_size)

    if input_size[0] is None:
        adjust = (1, 1)
    else:
        adjust = (1 - input_size[0] % 2, 1 - input_size[1] % 2)

    correct = (kernel_size[0] // 2, kernel_size[1] // 2)

    return ((correct[0] - adjust[0], correct[0]),
            (correct[1] - adjust[1], correct[1]))

def cbam_block(cbam_feature,ratio=8,act='relu'):
    '''
    Adaptation from convolutional block attention module (CBAM) block 
    GITHUB: https://github.com/kobiso/CBAM-keras/blob/master/models/attention_module.py
    '''  
    cbam = channel_attention(cbam_feature,ratio=ratio,act=act)
    cbam = spatial_channel(cbam,act=act)
    return cbam

def channel_attention(input_feature,ratio=8,act='relu'):
    '''
    Adaptation from convolutional block attention module (CBAM) block 
    GITHUB: https://github.com/kobiso/CBAM-keras/blob/master/models/attention_module.py
    '''
    channel = K.int_shape(input_feature)[3] #Assumption channel last
    
    avg_p = GlobalAveragePooling2D()(input_feature)
    avg_p = Reshape((1,1,channel))(avg_p)
    avg_p = Dense(channel//ratio,activation=act,
                  kernel_initializer='he_normal',
                  use_bias=True,
                  bias_initializer='zeros')(avg_p)
    avg_p = Dense(channel,kernel_initializer='he_normal',
                  use_bias=True,
                  bias_initializer='zeros')(avg_p)
    
    max_p = GlobalMaxPool2D()(input_feature)
    max_p = Reshape((1,1,channel))(max_p)
    max_p = Dense(channel//ratio,activation=act,
                  kernel_initializer='he_normal',
                  use_bias=True,
                  bias_initializer='zeros')(max_p)
    max_p = Dense(channel,
                  kernel_initializer='he_normal',
                  use_bias=True,
                  bias_initializer='zeros')(max_p)
    scale = Add()([avg_p,max_p])
    scale = Activation('sigmoid')(scale)
    
    return Multiply()([input_feature,scale])
    
def spatial_channel(input_feature,kernel_size=7,act='relu'):
    '''
    Spatial_channel attention module for CBAM
    '''
    avg_p = Lambda(lambda x: K.mean(x,axis=3,keepdims=True))(input_feature)
    max_p = Lambda(lambda x: K.max(x,axis=3,keepdims=True))(input_feature)
    concat = concatenate(axis=3)([avg_p,max_p])
    scale = keras_conv_2d(concat,kernel_size,kernel_size,1,act='sigmoid')
    
    return Multiply()([input_feature,scale])

def channel_shuffle(x,groups):
    """
    Adaptation:
        GitHUB: https://github.com/scheckmedia/keras-shufflenet/blob/master/shufflenet.py
    
    Channel shuffle operation from 'ShuffleNet: An Extremely Efficient Convolutional Neural Network for Mobile Devices,'
    https://arxiv.org/abs/1707.01083.
    Parameters:
    ----------
    x : keras.backend tensor/variable/symbol
        Input tensor/variable/symbol.
    groups : int
        Number of groups.
    Returns
    -------
    keras.backend tensor/variable/symbol
        Resulted tensor/variable/symbol.
    """
    height, width, in_channels = x.shape.as_list()[1:]
    channels_per_group = in_channels // groups

    x = K.reshape(x, [-1, height, width, groups, channels_per_group])
    x = K.permute_dimensions(x, (0, 1, 2, 4, 3))  # transpose
    x = K.reshape(x, [-1, height, width, in_channels])
    
    return x
    

def shuffle_block(input_feature,in_channels,out_channels,groups,bottleneck_ratio=0.25,act='relu',strides=1):
    '''
    GitHUB: [https://github.com/scheckmedia/keras-shufflenet/blob/master/shufflenet.py]
    
    '''
    # default: 1/4 of the output channel of a ShuffleNet Unit
    bottleneck_channels = int(out_channels * bottleneck_ratio)
    x = group_conv(input_feature,in_channels,bottleneck_channels,groups,act=None)
    x = BatchNormalization()(x)
    x = Activation(act)(x)
    x = Lambda(channel_shuffle,arguments={'groups': groups})(x)
    x = DepthwiseConv2D(kernel_size=(3,3), padding="same", use_bias=False,
                        depthwise_initializer='he_normal',
                        depthwise_regularizer=l2(0.0005),
                        strides=strides)(x)
    x = BatchNormalization()(x)
    x = group_conv(x, bottleneck_channels, out_channels=out_channels if strides == 1 else out_channels - in_channels,
                    groups=groups)
    x = BatchNormalization()(x)
    
    if strides < 2:
        out = Add()([x,input_feature])
    else:
        avg = AveragePooling2D(pool_size=3,strides=strides,padding='same')(input_feature)
        out = concatenate([x,avg])
    out = Activation(act)(out)
    return out
    
    
    
def group_conv(x,in_channels,out_channels,groups,kernel_size=1,stride=1,act='relu'):
    '''
    '''
    if groups ==1:
        return keras_conv_2d(x,out_channels,kernel_size,kernel_size, act=act,
                      use_bias=False, strides=stride)
    ig = in_channels // groups
    group_list = []
    
    for i in range(groups):
        offset = i * ig
        group = Lambda(lambda z: z[:, :, :, offset: offset + ig])(x)
        group_list.append(keras_conv_2d(group,int(0.5 + out_channels / groups),kernel_size,
                                        kernel_size,strides=stride,act=act,applyBatchNom=False))
    return concatenate(group_list)