# -*- coding: utf-8 -*-
"""
Created on Wed Jan 29 22:59:04 2020

@author: sonat
"""

from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input)
from model import cnnBB

__all__=['shuffleNet']

def shuffleNet(dataConfig,learning_rate=1e-2):
    '''
    ShuffleNet V1
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((256,256,1)))
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,strides=(2,2))
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.shuffle_block(x,64,64,4)
    x = cnnBB.shuffle_block(x,64,128,4,strides=2)
    x = cnnBB.shuffle_block(x,128,128,4)
    x = cnnBB.shuffle_block(x,128,256,4,strides=2)
    x = cnnBB.shuffle_block(x,256,256,4)
    x = cnnBB.shuffle_block(x,256,512,4,strides=2)
    x = cnnBB.shuffle_block(x,512,512,4)
    x = cnnBB.shuffle_block(x,512,1024,4,strides=2)
    x = cnnBB.shuffle_block(x,1024,1024,4)
    x = cnnBB.shuffle_block(x,1024,1024,4)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model