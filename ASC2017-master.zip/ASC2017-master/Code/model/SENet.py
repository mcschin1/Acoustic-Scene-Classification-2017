# -*- coding: utf-8 -*-
"""
Created on Mon Jan  6 16:40:26 2020

@author: sonat
"""
from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input)
from model import cnnBB

__all__=['SENET','res_SENET']

def SENET(dataConfig,learning_rate=1e-2):
    '''
    Squeeze-excitation Network adaptation
    
    Pure SE module stacks adaptation.
    
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,strides=2)
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.SENet_block(x,64)
    x = cnnBB.keras_conv_2d(x,128,3,3)
    x = cnnBB.MaxPooling2D(2,strides=2)(x)
    x = cnnBB.SENet_block(x,128)
    x = cnnBB.keras_conv_2d(x,256,3,3)
    x = cnnBB.keras_conv_2d(x,256,3,3)
    x = cnnBB.MaxPooling2D(2,strides=2)(x)
    x = cnnBB.SENet_block(x,256)
    x = cnnBB.keras_conv_2d(x,512,3,3)
    x = cnnBB.keras_conv_2d(x,512,3,3)
    x = cnnBB.MaxPooling2D(2,strides=2)(x)
    x = cnnBB.SENet_block(x,512)
    x = cnnBB.keras_conv_2d(x,1024,3,3)
    x = cnnBB.keras_conv_2d(x,1024,3,3)
    x = cnnBB.MaxPooling2D(2,strides=2)(x)
    x = cnnBB.SENet_block(x,1024)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model

def res_SENET(dataConfig,learning_rate=1e-2):
    '''
    Squeeze-excitation Network adaptation
    M
    
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,strides=2)
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.resSENet_block(x,32,conv_shortcut=True)
    x = cnnBB.resSENet_block(x,32,conv_shortcut=False)
    x = cnnBB.resSENet_block(x,64,conv_shortcut=True)
    x = cnnBB.resSENet_block(x,64,conv_shortcut=False)
    x = cnnBB.resSENet_block(x,128,conv_shortcut=True)
    x = cnnBB.resSENet_block(x,128,conv_shortcut=False)
    x = cnnBB.resSENet_block(x,256,conv_shortcut=True)
    x = cnnBB.resSENet_block(x,256,conv_shortcut=False)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model