# -*- coding: utf-8 -*-
"""
Created on Mon Dec 30 14:32:11 2019

@author: sonat
"""
from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input)
from model import cnnBB


__all__=['mobileNet','mobileNetV2']

def mobileNet(dataConfig,learning_rate=0.001,alpha=1):
    '''
    #Arguments
        dataConfig: Class DataConfig
        
        learning_rate: double
            The learning rate of the model. This is default to 0.001
        
        alpha: double  
            Is default as 1.
        
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,strides=(2,2),alpha=alpha)
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.mobilenet_depthwise_sep_block(x,128,3,stride=2,alpha=alpha)
    x = cnnBB.mobilenet_depthwise_sep_block(x,128,3,alpha=alpha)
    x = cnnBB.mobilenet_depthwise_sep_block(x,256,3,stride=2,alpha=alpha)
    x = cnnBB.mobilenet_depthwise_sep_block(x,256,3,alpha=alpha)
    x = cnnBB.mobilenet_depthwise_sep_block(x,512,3,stride=2,alpha=alpha)
    x = cnnBB.mobilenet_depthwise_sep_block(x,512,3,alpha=alpha)
    x = cnnBB.mobilenet_depthwise_sep_block(x,1024,3,stride=2,alpha=alpha)
    x = cnnBB.mobilenet_depthwise_sep_block(x,1024,3,alpha=alpha)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model



def mobileNetV2(dataConfig,learning_rate=0.001,alpha=0.75):
    '''
    Adaptation from MobileNetV2
        :[]
    
    #Arguments
            
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))    
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,strides=(2,2),alpha=alpha)
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.mobilenetV2_depthwise_sep_block(x,32,3,alpha=alpha)
    x = cnnBB.mobilenetV2_depthwise_sep_block(x,64,3,stride=2,expansion=6,alpha=alpha)
    x = cnnBB.mobilenetV2_depthwise_sep_block(x,128,3,stride=2,expansion=6,alpha=alpha)
    x = cnnBB.mobilenetV2_depthwise_sep_block(x,256,3,stride=2,expansion=6,alpha=alpha)
    x = cnnBB.mobilenetV2_depthwise_sep_block(x,256,3,stride=2,expansion=6,alpha=alpha)
    x = cnnBB.mobilenetV2_depthwise_sep_block(x,512,3,expansion=6,alpha=alpha)
    x = cnnBB.mobilenetV2_depthwise_sep_block(x,512,3,expansion=6,alpha=alpha)
    x = cnnBB.mobilenetV2_depthwise_sep_block(x,1024,3,expansion=6,alpha=alpha)
    x = cnnBB.mobilenetV2_depthwise_sep_block(x,1024,3,expansion=6,alpha=alpha)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model
    