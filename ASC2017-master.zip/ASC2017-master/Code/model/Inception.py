# -*- coding: utf-8 -*-
"""
Created on Sun Dec 22 17:35:46 2019

@author: sonat
"""
from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input)
from model import cnnBB

__all__=['Inception']

def Inception(dataConfig,learning_rate=0.001,input_tensor=None):
    '''
    With stem is being used
    
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    #stem
    incept= cnnBB.keras_conv_2d(input_shape,64,7,7)
    incept= cnnBB.MaxPooling2D((3,6))(incept)
    #layer2
    incept=cnnBB.incep_block1(incept,64)
    #Layer3 dim reduction
    incept=cnnBB.incep_dim_reduce3x3(incept,128)
    #Layer4
    incept=cnnBB.incep_block1(incept,128)
    #Layer5 dim reduction
    incept=cnnBB.incep_dim_reduce3x3(incept,192)
    #Layer6
    incept=cnnBB.incep_block2(incept,192,128,True)
    #Layer7
    incept=cnnBB.incep_dim_reduce7x7(incept,256)
    #Layer8
    incept=cnnBB.incep_block2(incept,256,192,True)
    final = GlobalAveragePooling2D()(incept)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model