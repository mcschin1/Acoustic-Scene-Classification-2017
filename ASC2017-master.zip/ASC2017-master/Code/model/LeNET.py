# -*- coding: utf-8 -*-
"""
Created on Tue Dec 17 15:47:18 2019

@author: sonat
"""
from keras.activations import relu, softmax
from keras import losses, models, optimizers
from keras.layers import (Convolution2D, GlobalAveragePooling2D, BatchNormalization, Flatten,Conv2D,Reshape,MaxPooling2D,Dot,
                          GlobalMaxPool2D, MaxPool2D, concatenate, Activation,Dense,Input, AveragePooling2D,
                          Lambda,SpatialDropout2D)
from keras.utils import Sequence, to_categorical


def LENet(dataConfig,learning_rate=0.001,input_tensor=None):
    '''
    Instantiates the LeNET architecture
    LeNET architecture design:
        Conv1: Filter size (5,5)
               No of Filter: 6
               stride: 1
               Padding: 0
        Pool2: Filter size (2,2)
               No of Filter: 6
               stride: 2
               Padding: 0
        Conv3: Filter size (5,5)
               No of Filter: 16
               Stride: 1
               Padding: 0
        Pool4: Filter size (2,2)
               No of Filter: 16
               Stride: 2
               Padding: 0
        conv5: 120 depth with 5 x 5 kernel filters
        Dense6: 84 nodes
        output: no_classes
    
    # Arguments
        input_tensor:
            
        input_shape:

        
    # Returns
        A keras model instance.
        
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    conv1 = Convolution2D(6,kernel_size=(5,5),strides=(1,1),activation='tanh',padding='same')(input_shape)
    pool2 = AveragePooling2D((2,2),strides=(2,2))(conv1)
    conv3 = Convolution2D(16,kernel_size=(5,5),strides=(1,1),activation='tanh',padding='Valid')(pool2)
    pool4 = AveragePooling2D((2,2),strides=(2,2))(conv3)
    conv5 = Convolution2D(120,kernel_size=(5,5),strides=(1,1),activation='tanh',padding='Valid')(pool4)
    Fconv5 = Flatten()(conv5)
    dense6 = Dense(84,activation='tanh')(Fconv5)
    out = Dense(dataConfig.n_classes,activation=softmax)(dense6)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model


def test():
    model=LENet((80,470,1))