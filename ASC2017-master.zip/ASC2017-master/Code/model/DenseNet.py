# -*- coding: utf-8 -*-
"""
Created on Wed Jan  1 12:43:41 2020

@author: sonat
"""
from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input)
from model import cnnBB

__all__=['denseNet']

def denseNet(dataConfig,learning_rate=0.001):
    '''
    #Adaptation from DenseNet
     by: 
    
    # Arguments
    
    # Returns
         Keras.model instance
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,strides=2)
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.dense_block(x,6)
    x = cnnBB.transition_block(x)
    x = cnnBB.dense_block(x,12)
    x = cnnBB.transition_block(x)
    x = cnnBB.dense_block(x,24)
    x = cnnBB.transition_block(x)
    x = cnnBB.dense_block(x,48)
    x = cnnBB.transition_block(x)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model