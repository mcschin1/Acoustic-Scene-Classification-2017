# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 11:02:38 2019

@author: kekxi
"""
from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling1D,GlobalMaxPool1D,Dense,Input)
from model import cnnBB

__all__=['rawResWCNN']

def rawResWCNN(dataConfig,learning_rate=0.001):
    '''
    Adaptation from :VERY DEEP CONVOLUTIONAL NEURAL NETWORKS FOR RAW WAVEFORMS
    
    based on 42ms of downsampled raw waveform of 22050 of 10sec
    kernel size for the first input is 22050 * 0.020 = |441|
    stride is set to 50% hop length = 441//2 = 220
    
    
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=(220500,1))
    x = cnnBB.keras_conv_1d(input_shape, 32,16,
                            applyBatchNom=True,act='relu')
    x = cnnBB.MaxPooling1D(4,strides=4)(x)
    x = cnnBB.keras_conv_1d(x, 64,16,
                            applyBatchNom=True,act='relu')
    x = cnnBB.MaxPooling1D(4,strides=4)(x)
    x = cnnBB.keras_conv_1d(x, 128,16,
                            applyBatchNom=True,act='relu')
    x = cnnBB.MaxPooling1D(4,strides=4)(x)
    x = cnnBB.keras_conv_1d(x, 256,16,
                            applyBatchNom=True,act='relu')
    x = cnnBB.MaxPooling1D(4,strides=4)(x)
    x = cnnBB.keras_conv_1d(x, 512,16,
                            applyBatchNom=True,act='relu')
    x = cnnBB.MaxPooling1D(4,strides=4)(x)
    '''
    x = cnnBB.res_block_1d(x,32,16,stride=4,padding=8)
    x = cnnBB.res_block_1d(x,64,12,stride=4,padding=4)
    x = cnnBB.res_block_1d(x,128,12,stride=4,padding=4)
    x = cnnBB.res_block_1d(x,256,8,stride=2,padding=4)
    x = cnnBB.res_block_1d(x,512,8,stride=2,padding=4)
    x = cnnBB.res_block_1d(x,512,8,stride=2,padding=3)
    x = cnnBB.res_block_1d(x,512,8,stride=2,padding=3)
    '''
    final = GlobalAveragePooling1D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model