# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 11:45:59 2019

@author: sonat
"""
__all__=['VGG','VGG2','AlexNet','AlexNet2','firstCNN','firstCNN2019norm','firstCNN2019norm2']

from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input)
from model import cnnBB

def VGG(dataConfig,learning_rate=0.001,input_tensor=None):
    input_shape= Input(shape=(dataConfig.input_shape))
    #1&2 layers
    vggBlock1 = cnnBB.vgg_block(input_shape,32)
    #3&4 layers
    vggBlock2 = cnnBB.vgg_block(vggBlock1,64)
    #5&6 layers
    vggBlock3 = cnnBB.vgg_block(vggBlock2,128)
    #7&8 layers
    vggBlock4 = cnnBB.vgg_block(vggBlock3,256)
    #9&10 layers
    #vggBlock4 = cnnBB.vgg_block(vggBlock4,1024)
    max_p = GlobalMaxPool2D()(vggBlock4)
    avg_p = GlobalAveragePooling2D()(vggBlock4)
    final = cnnBB.Add()([max_p,avg_p])
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model

def VGG2(dataConfig,learning_rate=0.001,input_tensor=None):
    input_shape= Input(shape=(dataConfig.input_shape))
    #1&2 layers
    vggBlock1 = cnnBB.vgg_block(input_shape,32,pool_size=(5,5))
    #3&4 layers
    vggBlock2 = cnnBB.vgg_block(vggBlock1,64,pool_size=(5,5))
    #5&6 layers
    vggBlock3 = cnnBB.vgg_block(vggBlock2,128)
    #7&8 layers
    vggBlock4 = cnnBB.vgg_block(vggBlock3,256)
    #9&10 layers
    #vggBlock4 = cnnBB.vgg_block(vggBlock4,1024)
    final = GlobalMaxPool2D()(vggBlock4)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model

def AlexNet(dataConfig,learning_rate=0.001,input_tensor=None):
    input_shape = Input(shape=(dataConfig.input_shape))
    #input_shape=Input(shape=(80,470,1))
    #Layer1
    x = cnnBB.keras_conv_2d(input_shape, 96, 11, 11,strides=(4,4),padding='valid')
    x = cnnBB.MaxPooling2D((3,3))(x)
    x = cnnBB.keras_conv_2d(x, 256, 5, 5)
    x = cnnBB.MaxPooling2D((3,3))(x)
    x = cnnBB.keras_conv_2d(x, 256, 5, 5)
    x = cnnBB.keras_conv_2d(x,384,3,3)
    final = GlobalMaxPool2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model
    
def AlexNet2(dataConfig,learning_rate=0.001,input_tensor=None):
    input_shape = Input(shape=(dataConfig.input_shape))
    #input_shape=Input(shape=(80,470,1))
    #Layer1
    x = cnnBB.keras_conv_2d(input_shape, 32, 11, 11,act='relu')
    x = cnnBB.MaxPooling2D((5,5))(x)
    x = cnnBB.keras_conv_2d(x, 64, 7, 7,act='relu')
    x = cnnBB.MaxPooling2D((5,5))(x)
    x = cnnBB.keras_conv_2d(x, 128, 5, 5,act='relu')
    x = cnnBB.MaxPooling2D((3,3))(x)
    x = cnnBB.keras_conv_2d(x, 256, 3,3,act='relu')
    #x = cnnBB.keras_conv_2d(x,384,3,3)
    final = GlobalMaxPool2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model

def firstCNN(dataConfig,learning_rate=0.001,input_tensor=None):
    '''
    First proposed mel-scale spectrogram to CNN for ASC tasks.
    '''
    input_shape=Input(shape=(dataConfig.input_shape))
    #input_shape=Input(shape=(80,470,1))
    #Layer1
    x = cnnBB.keras_conv_2d(input_shape,128,5,5)
    x = cnnBB.MaxPooling2D((5,5))(x)
    x = cnnBB.keras_conv_2d(x,256,5,5)
    x = cnnBB.MaxPooling2D((4,94))(x)
    final = Flatten()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model

def firstCNN2019norm(dataConfig,learning_rate=0.001,input_tensor=None):
    '''
    First proposed mel-scale spectrogram to CNN for ASC tasks. 63%
    '''
    input_shape=Input(shape=(dataConfig.input_shape))
    #input_shape=Input(shape=(80,470,1))
    #Layer1
    act='relu'
    x = cnnBB.keras_conv_2d(input_shape,64,5,5,act=act)
    x = cnnBB.MaxPooling2D((5,5))(x)
    x = cnnBB.keras_conv_2d(x,128,5,5,act=act)
    x = cnnBB.MaxPooling2D((5,5))(x)
    x = cnnBB.keras_conv_2d(x,256,5,5,act=act)
    x = cnnBB.MaxPooling2D((5,5))(x)
    #x = cnnBB.MaxPooling2D((10,18))(x) <for 256 by 470
    final = Flatten()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model

def firstCNN2019norm2(dataConfig,learning_rate=0.001,input_tensor=None):
    '''
    First proposed mel-scale spectrogram to CNN for ASC tasks. 61%
    '''
    input_shape=Input(shape=(dataConfig.input_shape))
    #input_shape=Input(shape=(80,470,1))
    #Layer1
    act='relu'
    x = cnnBB.keras_conv_2d(input_shape,32,5,5,act=act)
    x = cnnBB.MaxPooling2D((5,5))(x)
    x = cnnBB.keras_conv_2d(x,128,5,5,act=act)
    x = cnnBB.MaxPooling2D((5,5))(x)
    x = cnnBB.keras_conv_2d(x,256,5,5,act=act)
    x = cnnBB.MaxPooling2D((5,5))(x)
    x = cnnBB.keras_conv_2d(x,512,5,5,act=act)
    x = cnnBB.MaxPooling2D((2,3))(x)
    final = Flatten()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model
