# -*- coding: utf-8 -*-
"""
Created on Sun Dec 29 16:17:19 2019

@author: sonat
"""
from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input)
from model import cnnBB

__all__=['Xception']

def Xception(dataConfig,learning_rate=0.001):
    
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,strides=2,padding='valid',act='relu')
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    '''
    res=cnnBB.keras_conv_2d(x,128,1,1,strides=2)
    x = cnnBB.keras_separable_conv_2d(x,128,3,act='relu')
    x = cnnBB.keras_separable_conv_2d(x,128,3)
    x = cnnBB.MaxPooling2D((3,3),strides=2,padding='same')(x)
    x = cnnBB.Add()([x,res])
    '''
    x = cnnBB.Xception_block(x,64,3,stride=1)
    x = cnnBB.Xception_block(x,128,3)
    x = cnnBB.Xception_block(x,128,3,stride=1)
    x = cnnBB.Xception_block(x,256,3)
    x = cnnBB.Xception_block(x,256,3,stride=1)
    x = cnnBB.Xception_block(x,512,3)
    x = cnnBB.Xception_block(x,512,3,stride=1)
    x = cnnBB.Xception_block(x,1024,3)
    x = cnnBB.Xception_block(x,1024,3,stride=1)
    x = cnnBB.Xception_block(x,1024,3,stride=1)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    return model
    