# -*- coding: utf-8 -*-
"""
Created on Sat Jan  4 13:20:01 2020

@author: sonat
"""
from keras.activations import softmax
from keras import losses, models, optimizers
from keras.layers import (Flatten,GlobalAveragePooling2D,GlobalMaxPool2D,Dense,Input)
from model import cnnBB

__all__=['highwayNet','highwayNetNoStem']

def highwayNet(dataConfig,learning_rate=0.001):
    '''
    Highway Network adaptation
    
    
    
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    x = cnnBB.keras_conv_2d(input_shape,64,7,7,strides=2)
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.highway_block(x,128,conv=True)
    x = cnnBB.highway_block(x,128)
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.highway_block(x,256,conv=True)
    x = cnnBB.highway_block(x,256)
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.highway_block(x,512,conv=True)
    x = cnnBB.highway_block(x,512)
    x = cnnBB.MaxPooling2D(3,strides=2)(x)
    x = cnnBB.highway_block(x,1024,conv=True)
    x = cnnBB.highway_block(x,1024)
    final = GlobalAveragePooling2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model
    
def highwayNetNoStem(dataConfig,learning_rate=1e-2):
    '''
    '''
    input_shape= Input(shape=(dataConfig.input_shape))
    #input_shape= Input(shape=((80,470,1)))
    x = cnnBB.highway_block(input_shape,64,H_kernel_size=5,W_kernel_size=5,conv=True)
    x = cnnBB.MaxPooling2D(5)(x)
    x = cnnBB.highway_block(x,128,H_kernel_size=5,W_kernel_size=5,conv=True)
    x = cnnBB.highway_block(x,128)
    x = cnnBB.MaxPooling2D(16)(x)
    x = cnnBB.highway_block(x,256,H_kernel_size=5,W_kernel_size=5,conv=True)
    x = cnnBB.highway_block(x,256)
    final = GlobalMaxPool2D()(x)
    out = Dense(dataConfig.n_classes,activation=softmax)(final)
    model = models.Model(inputs=input_shape,outputs=out)
    opt = optimizers.Adam(learning_rate)
    model.compile(optimizer=opt,loss=losses.categorical_crossentropy, metrics=['acc'])
    
    return model
    
    
    