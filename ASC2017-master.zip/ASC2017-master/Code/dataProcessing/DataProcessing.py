# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 11:33:13 2019

@author: sonat
"""
import os
from feature_extraction import featureExtraction as fe
import yaml
import numpy as np
from keras.utils import Sequence, to_categorical
from keras.callbacks import LambdaCallback
import pickle


class Normalizer(object):
    def __init__(self,n=None,s1=None,s2=None,mean=None,std=None,filename=None):
        self.n = n
        self.s1 = s1
        self.s2 = s2
        self.mean = mean
        self.std = std
        if filename is not None:
            with open('./sys_folder/{0}.pkl'.format(filename),'rb') as input:
                norm = pickle.load(input)
                self.mean = norm.mean
                self.std = norm.std
        
    def accumulate(self,data,time_axis=1):
        n = data.shape[1]
        s1 = np.mean(data, axis=1)
        s2 = np.sum(data ** 2, axis=1)
        mean = np.mean(data, axis=1)
        std = np.std(data,axis=1)
        if self.n is None:
            self.n = n
        else:
            self.n += n
        if self.s1 is None:
            self.s1 = s1
        else:
            self.s1 += s1
        if self.s2 is None:
            self.s2 = s2
        else:
            self.s2 += s2
        return self
    
    def finalize_and_save(self,filename):
        '''
        After accumulating all the statistic,
        we get the mean and std
        This command will also save the file into sys_folder
        '''
        self.mean = (self.s1 / self.n).reshape(-1, 1)
        self.std = np.sqrt((self.n * self.s2 - (self.s1 * self.s1)) / (self.n * (self.n - 1))).reshape(-1, 1)
        with open('./sys_folder/{0}.pkl'.format(filename),'wb') as out:
            pickle.dump(self,out, pickle.HIGHEST_PROTOCOL)
            
    def normalize(self,data):
        return (data - self.mean) / self.std

class DataConfig(object):
    def __init__(self,height,width,n_channels,n_classes,norm=None,is_1D=False,channel_last=True):
        self.height=height
        self.width=width
        self.n_channels=n_channels
        self.n_classes=n_classes
        self.is_1D=is_1D
        self.channel_last=channel_last
        if is_1D:
            self.input_shape=(self.width,self.n_channels)
        else:
            self.input_shape=(self.height,self.width,self.n_channels)
        self.norm=norm

class DataGenerator(Sequence):
    def __init__(self,config,data_dir,list_IDs,labels=None,shuffle=True,batch_size=32):
        self.data_dir = data_dir
        self.list_IDs = list_IDs
        self.labels = labels
        self.batch_size = batch_size
        self.config = config
        self.shuffle = shuffle
        self.on_epoch_end()
    
    def __len__(self):
        return int(np.ceil(len(self.list_IDs) / self.batch_size))

    def __getitem__(self, index):
        indexes = self.indexes[index*self.batch_size:(index+1)*self.batch_size]
        list_IDs_temp = [self.list_IDs[k] for k in indexes]
        return self.__data_generation(list_IDs_temp)
    
    def on_epoch_end(self):
        self.indexes = np.arange(len(self.list_IDs))
        if self.shuffle == True:
            np.random.shuffle(self.indexes)
        

    def __data_generation(self, list_IDs_temp):
        cur_batch_size = len(list_IDs_temp)
        if self.config.is_1D:
            X = np.empty((cur_batch_size,self.config.input_shape[0],self.config.input_shape[1])
                         , dtype=np.float64)
            for i, ID in enumerate(list_IDs_temp):
                waveform = np.load(self.data_dir+ID+'.npy')
                H_data = np.expand_dims(waveform[:self.config.width],axis=-1)
                X[i,] = H_data
        else:
            X = np.empty((cur_batch_size,self.config.input_shape[0],self.config.input_shape[1],
                      self.config.input_shape[2]), dtype=np.float64)
            for i, ID in enumerate(list_IDs_temp):
                waveform = np.load(self.data_dir+ID+'.npy')
                #waveform = self.config.norm.normalize(waveform)
                H_data = waveform[:self.config.height,:self.config.width]
                H_data = np.expand_dims(H_data, axis=-1)
                X[i,] = H_data
            
        if self.labels is not None:
            y = np.empty(cur_batch_size, dtype=int)
            for i, ID in enumerate(list_IDs_temp):
                y[i] = self.labels[ID]
            return X,to_categorical(y, num_classes=self.config.n_classes)
        else:
            return X

class MixUpGenerator(Sequence):
    def __init__(self,config,data_dir,list_IDs, labels=None, batch_size=32, alpha=0.2, shuffle=True, datagen=None):
        self.config=config
        self.data_dir=data_dir
        self.list_IDs = list_IDs
        self.labels = labels
        self.batch_size = batch_size
        self.alpha = alpha
        self.shuffle = shuffle
        self.sample_num = len(list_IDs)
        self.datagen = datagen
        self.on_epoch_end()
    
    def __len__(self):
        return int(np.ceil(len(self.list_IDs) / self.batch_size))

    def __getitem__(self, index):
        indexes = self.indexes[index*self.batch_size:(index+1)*self.batch_size]
        '''
        Randomly select audio file based on indexes for mixing.
        '''
        mix_indexes = np.random.choice(self.indexes[np.isin(self.indexes,indexes,invert=True)]
                                       ,size=self.batch_size,replace=False)
        mixup_IDs = [self.list_IDs[k] for k in mix_indexes]
        list_IDs_temp = [self.list_IDs[k] for k in indexes]
        return self.__data_generation(list_IDs_temp,mixup_IDs)
    
    def on_epoch_end(self):
        self.indexes = np.arange(len(self.list_IDs))
        if self.shuffle == True:
            np.random.shuffle(self.indexes)
    
    def get_steps_per_epoch(self):
        """Get number of steps per epoch based on batch size and
        number of images.
        Returns:
            int -- steps per epoch.
        """
        return self.list_IDs // self.batch_size
    '''
    def __call__(self):
        while True:
            indexes = self.__get_exploration_order()
            itr_num = int(len(indexes) // (self.batch_size * 2))

            for i in range(itr_num):
                batch_ids = indexes[i * self.batch_size * 2:(i + 1) * self.batch_size * 2]
                X, y = self.__data_generation(batch_ids)

                yield X, y
    
    
    def __get_exploration_order(self):
        indexes = np.arange(self.sample_num)
        if self.shuffle:
            np.random.shuffle(indexes)
        return indexes
    '''
    def __data_generation(self, batch_ids,mixup_IDs):
        X1 = np.empty((self.batch_size,self.config.input_shape[0],self.config.input_shape[1],
                      self.config.input_shape[2]), dtype=np.float64)
        X2 = np.empty((self.batch_size,self.config.input_shape[0],self.config.input_shape[1],
                      self.config.input_shape[2]), dtype=np.float64)
        l = np.random.beta(self.alpha, self.alpha, self.batch_size)
        #l = np.random.beta(0.1, 0.9, self.batch_size)
        X_l = l.reshape(self.batch_size, 1, 1, 1)
        y_l = l.reshape(self.batch_size, 1)
        
        for i,ID in enumerate(batch_ids):
            waveform = np.load(self.data_dir+ID+'.npy')
            #waveform = self.config.norm.normalize(waveform)
            H_data = waveform[:self.config.height,:self.config.width]
            H_data = np.expand_dims(H_data, axis=-1)
            X1[i,] = H_data
        
        for i,ID in enumerate(mixup_IDs):
            waveform = np.load(self.data_dir+ID+'.npy')
            #waveform = self.config.norm.normalize(waveform)
            H_data = waveform[:self.config.height,:self.config.width]
            H_data = np.expand_dims(H_data, axis=-1)
            X2[i,] = H_data

        X = X1 * X_l + X2 * (1 - X_l)
        '''Might want to consider adding the actual value too.
        '''
        if self.labels is not None:
            y1 = np.empty(self.batch_size, dtype=int)
            y2 = np.empty(self.batch_size, dtype=int)
            for i, ID in enumerate(batch_ids):
                y1[i] = self.labels[ID]
            for i, ID in enumerate(mixup_IDs):
                y2[i] = self.labels[ID]
            try:
                y1 = to_categorical(y1, num_classes=self.config.n_classes)
                y2 = to_categorical(y2, num_classes=self.config.n_classes)
            except ValueError:
                print(y1)
                print(y2)
            y =  y1 * y_l + y2 * (1 - y_l)
            return X,y
        else:
            return X


def mixup(data,one_hot_labels,alpha=1,batch_size=32):
    np.random.seed(42)
    weights = np.random.beta(alpha, alpha, batch_size)
    index = np.random.permutation(batch_size)
    x1, x2 = data, data[index]
    x = np.array([x1[i] * weights [i] + x2[i] * (1 - weights[i]) for i in range(len(weights))])
    y1 = np.array(one_hot_labels).astype(np.float)
    y2 = np.array(np.array(one_hot_labels)[index]).astype(np.float)
    y = np.array([y1[i] * weights[i] + y2[i] * (1 - weights[i]) for i in range(len(weights))])
    return x, y


def DataProcessing(filelist,writeDir,readDir,method='melscale'):
    #featureExtractor = fe.FeatureExtractor(48000,10,78,n_mels=256)
    #featureExtractor = fe.FeatureExtractor(48000,10,42,n_mels=256)
    #for 2017 featureExtractor = fe.FeatureExtractor(44100,10,42,n_mels=80)
    featureExtractor = fe.FeatureExtractor(44100,10,156,n_mels=128)
    for i in filelist:
        filepath=readDir+i
        name = i.split('.')[0]
        writepath=writeDir+name+'.npy'
        melspec=featureExtractor.audio_to_melspectrogram(filepath)
        np.save(writepath,melspec ,allow_pickle=True)

def DataProcessingRaw(filelist,writeDir,readDir):
    for i in filelist:
        filepath=readDir+i
        name = i.split('.')[0]
        writepath=writeDir+name+'.npy'
        waveform , _ = fe.librosa.core.load(filepath,sr=32000)
        np.save(writepath,waveform,allow_pickle=True)

def draft_process_data():
    filelist = [f for f in os.listdir("../Dataset/TUT-acoustic-scenes-2017-evaluation/audio") 
                if os.path.isfile(os.path.join("../Dataset/TUT-acoustic-scenes-2017-evaluation/audio", f))]
    writeDir='../Processed/melscale82_128/melscale'
    readDir='../Dataset/TUT-acoustic-scenes-2017-evaluation/audio/'
    if not os.path.exists(writeDir):
        os.mkdir(writeDir)
    DataProcessing(filelist,writeDir,readDir)
    #DataProcessingRaw(filelist,writeDir,readDir)
    data = np.load(writeDir+'a001_0_10.npy',allow_pickle=True)
    ##Datasize: 80 by 476



    
def getNormalizeMap(readDir,trainset,testset):
    norm = Normalizer()
    trainset = trainset.append(testset)
    for index, row in trainset.iterrows():
        data = np.load(readDir+index+'.npy')
        norm.accumulate(data)      
    norm.finalize_and_save('norm2017_fold01')
    

    
'''
i=1
trainset = pd.read_csv('../Dataset/TUT-acoustic-scenes-2017-development/evaluation_setup/fold{0}_train.csv'.format(str(i)),
                                   index_col='filename')
testset = pd.read_csv('../Dataset/TUT-acoustic-scenes-2017-development/evaluation_setup/fold{0}_evaluate.csv'.format(str(i)),
                                   index_col='filename')
'''
