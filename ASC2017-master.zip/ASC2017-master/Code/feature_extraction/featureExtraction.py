# -*- coding: utf-8 -*-
"""
Created on Mon Dec  2 11:14:17 2019

@author: sonat
"""
import numpy as np
import librosa
import scipy

class FeatureExtractor:
    def __init__(self,sampling_rate,audio_length,window_size_ms,hop_length_ratio=0.5,window_size=None,
                 hop_length=None,isMono=True,fmin=0,fmax=None,n_fft=None,n_mels=0
                 ):
        '''
        Constructors:
            sampling_rate: Sampling rate of the audio file in Hertz (E.g. 44.1KHz should be keyed in as 441000)
            audio_length: Duration of the audio file in seconds.
            window_size_ms: The size of the moving window measured in milliseconds
            hop_length_ratio: The hop_length ratio is between 0 to 1. default to 0.5 
                    which is 50% of the window size.
            window_size: the actual frame size of the window (best to be calculated)
            hop_length: the actual frame size of the hop_length (best to be calculated)
            isMono: Set the output of the processed audio signal to mono, Default is True
            fmin: high pass filter cutoff point. Default is 0. means no high-pass filter
            fmax: low pass filter cutoff point. Default is None. means no low-pass filter
                    if fmax is None, default to half of sampling_rate
            n_fft: Number of FFT per window, Default is None which will set the value to 
                    the next power of 2 of the window_size.
                    Note*: n_fft should not be less than window_size.
                           n_fft is best set to a value which is the power of 2 for 
                           optimal computational cost.
        '''
        self.window_size=window_size
        self.hop_length=hop_length
        self.window_size_ms=window_size_ms
        self.hop_length_ratio=hop_length_ratio
        self.sampling_rate=sampling_rate
        self.audio_length=audio_length
        self.n_fft =n_fft
        self.fmax=fmax
        if self.window_size is None:
            self.window_size = int(np.ceil((self.window_size_ms/1000)*self.sampling_rate))
        else:
            self.window_size=window_size
        if self.n_fft is None:
            self.n_fft = int(pow(2, np.ceil(np.log(self.window_size)/np.log(2))))
        if self.hop_length is None:
            self.hop_length= np.ceil(self.hop_length_ratio*self.window_size).astype(int)
        else:
            self.hop_length=hop_length
        self.isMono=isMono
        self.fmin=fmin
        if self.fmax is None:
            self.fmax = sampling_rate//2
        else:
            self.fmax=fmax
        self.n_mels=n_mels

    def audio_to_melspectrogram(self,filepath,normalize=False):
        '''
        log_mel_spec
        '''
        data, _ = librosa.core.load(filepath, duration=self.audio_length, mono=self.isMono, sr=self.sampling_rate)    
        mel_basis = librosa.filters.mel(sr=self.sampling_rate,
                                       n_fft=self.n_fft,
                                       n_mels=self.n_mels,
                                       fmin=self.fmin,
                                       fmax=self.fmax
                                       )
        eps = np.spacing(1)
        spectrogram = np.abs(librosa.stft(data+eps,
                                             n_fft=self.n_fft,
                                             win_length=self.window_size,
                                             hop_length=self.hop_length,
                                             center=True,
                                             window=scipy.signal.hamming(self.window_size, sym=False)
                                             )
                                )
        mel_spectrum = np.dot(mel_basis, spectrogram)
        mel_spectrum = np.log(mel_spectrum + eps)
        if normalize:
            mel_spectrum = librosa.util.normalize(mel_spectrum)
        return mel_spectrum

    
    def old_melspec(self,n_mels):
        self.n_mels=n_mels
        spectrogram = librosa.feature.melspectrogram(data, 
                                                     sr=self.sampling_rate,
                                                     n_mels=self.n_mels,
                                                     hop_length=self.hop_length,
                                                     n_fft=self.window_size,
                                                     fmin=self.fmin,
                                                     fmax=self.fmax)
        spectrogram = librosa.power_to_db(spectrogram)
        spectrogram = spectrogram.astype(np.float32)
        return spectrogram
            
        
        
        