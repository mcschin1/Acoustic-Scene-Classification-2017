# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 09:53:47 2019

@author: sonat

System setting for CPU and GPU usage
"""
from keras import backend as K
from keras.callbacks import (EarlyStopping, LearningRateScheduler,
                             ModelCheckpoint, TensorBoard, ReduceLROnPlateau,LambdaCallback)
import tensorflow as tf
import sys

class Logs(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush() # If you want the output to be visible immediately
    def flush(self) :
        for f in self.files:
            f.flush()
            

def startLogging(filepath):
     f = open(filepath,'w')
     original = sys.stdout
     sys.stdout = Logs(sys.stdout,f)
     return f,original
     
def closeLogging(f,original):
    sys.stdout = original
    f.close()

def testLogs():
    f = open('out.txt', 'w')
    original = sys.stdout
    sys.stdout = Logs(sys.stdout, f)
    print("test")  # This will go to stdout and the file out.txt
    
    #use the original
    sys.stdout = original
    print("This won't appear on file")  # Only on stdout
    f.close()
    
'''
num_cores = 1
GPU=True
CPU=False
if GPU:
    num_GPU = 1
    num_CPU = 1
if CPU:
    num_CPU = 1
    num_GPU = 0
config = tf.ConfigProto(allow_soft_placement=True,
                        intra_op_parallelism_threads=num_cores,
                        inter_op_parallelism_threads=num_cores, 
                        device_count = {'CPU' : num_CPU,
                                        'GPU' : num_GPU}
                        )
config.gpu_options.allocator_type = 'BFC'
config.gpu_options.per_process_gpu_memory_fraction = 0.80
'''
#session = tf.Session(config=config)
#K.clear_session()
#K.get_session().run(tf.global_variables_initializer())