# -*- coding: utf-8 -*-
"""
Created on Fri Jan  3 14:35:48 2020

@author: kekxi
"""
import os
import numpy as np
import pandas as pd

def loadLabel(filepath='./sys_folder/label_idx.npy'):
    labelList = {}
    if os.path.exists(filepath):
        labelList = np.load(filepath,allow_pickle=True)
        labelList = labelList.item()
        return labelList
    else:
        return None
    
def createLabel(LABELS,filepath='./sys_folder/label_idx.npy'):
    label_idx = {label: i for i, label in enumerate(LABELS)}
    np.save(filepath,label_idx)
    return label_idx

def extractMetaData(trainset,testset):
    trainset['label'] = trainset.filename.apply(lambda x: x.split('\t')[1])
    trainset['filename'] = trainset.filename.apply(lambda x: x.split('\t')[0].split('/')[1].split('.')[0])
    testset['label'] = testset.filename.apply(lambda x: x.split('\t')[1])
    testset['filename'] = testset.filename.apply(lambda x: x.split('\t')[0].split('/')[1].split('.')[0])
    label_idx = {}
    label_idx = loadLabel(filepath='./sys_folder/2019_label_idx.npy')
    if label_idx is None:
        LABELS = list(trainset.label.unique())
        label_idx = createLabel(LABELS,filepath='./sys_folder/2019_label_idx.npy')
    trainset['label_idx']=trainset.label.apply(lambda x: label_idx[x])
    testset['label_idx']=testset.label.apply(lambda x: label_idx[x])
    trainset.set_index("filename",inplace=True)
    testset.set_index("filename",inplace=True)
    return trainset,testset


def prepareMetaDataFrame():
    for i in range(1,5):
        trainset = pd.read_csv('../Dataset/TUT-acoustic-scenes-2017-development/evaluation_setup/fold{0}_train.txt'.format(str(i)),
                               header=None,names=['filename'])
        testset = pd.read_csv('../Dataset/TUT-acoustic-scenes-2017-development/evaluation_setup/fold{0}_evaluate.txt'.format(str(i)),
                               header=None,names=['filename'])
        trainset,testset=extractMetaData(trainset,testset)
        trainset.to_csv('../Dataset/TUT-acoustic-scenes-2017-development/evaluation_setup/fold{0}_train.csv'.format(str(i)))
        testset.to_csv('../Dataset/TUT-acoustic-scenes-2017-development/evaluation_setup/fold{0}_evaluate.csv'.format(str(i)))
        print('Completed saving dataFrame')
        
    
'''
trainset = pd.read_csv('../Dataset/TAU-urban-acoustic-scenes-2019-development/evaluation_setup/fold1_train.csv',names=['filename'])
testset = pd.read_csv('../Dataset/TAU-urban-acoustic-scenes-2019-development/evaluation_setup/fold1_evaluate.csv',
                               header=None,names=['filename'])
trainset.drop(0,inplace=True)
testset.drop(0,inplace=True)
trainset,testset=extractMetaData(trainset,testset)
trainset.to_csv('../Dataset/TAU-urban-acoustic-scenes-2019-development/evaluation_setup/fold{0}_train_df.csv'.format(str(1)))
testset.to_csv('../Dataset/TAU-urban-acoustic-scenes-2019-development/evaluation_setup/fold{0}_evaluate_df.csv'.format(str(1)))
'''

